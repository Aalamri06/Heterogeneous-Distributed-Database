module worker-node-1

go 1.26.3

require github.com/mattn/go-sqlite3 v1.14.44 // indirect
