package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

type ReplicationRequest struct {
	TableName string                 `json:"table_name"`
	Data      map[string]interface{} `json:"data"`
}
type UpdateRequest struct {
	TableName string                 `json:"table_name"`
	ID        int                    `json:"id"`
	Data      map[string]interface{} `json:"data"`
}
type DeleteRequest struct {
	TableName string `json:"table_name"`
	ID        int    `json:"id"`
}
type FileRequest struct {
	From string `json:"from"`
	To   string `json:"to"`
	File string `json:"file"`
}

func replicationHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request ReplicationRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	createQuery := fmt.Sprintf(
		"CREATE TABLE IF NOT EXISTS %s (id INTEGER PRIMARY KEY AUTOINCREMENT)",
		request.TableName,
	)

	_, err = DB.Exec(createQuery)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	var columns []string
	var placeholders []string
	var values []interface{}

	for key, value := range request.Data {

		columns = append(columns, key)
		placeholders = append(placeholders, "?")
		values = append(values, value)

		alterQuery := fmt.Sprintf(
			"ALTER TABLE %s ADD COLUMN %s TEXT",
			request.TableName,
			key,
		)

		DB.Exec(alterQuery)
	}

	insertQuery := fmt.Sprintf(
		"INSERT INTO %s (%s) VALUES (%s)",
		request.TableName,
		strings.Join(columns, ", "),
		strings.Join(placeholders, ", "),
	)

	_, err = DB.Exec(insertQuery, values...)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]string{
		"message": "Dynamic replication successful",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}

func replicateUpdateHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request UpdateRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	var setParts []string
	var values []interface{}

	for column, value := range request.Data {

		setParts = append(
			setParts,
			fmt.Sprintf("%s = ?", column),
		)

		values = append(values, value)
	}

	values = append(values, request.ID)

	query := fmt.Sprintf(`
		UPDATE %s
		SET %s
		WHERE id = ?
	`,
		request.TableName,
		strings.Join(setParts, ", "),
	)

	_, err = DB.Exec(query, values...)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(map[string]string{
		"message": "Worker dynamic update success",
	})
}

func replicateDeleteHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request DeleteRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf(
		"DELETE FROM %s WHERE id = ?",
		request.TableName,
	)

	_, err = DB.Exec(query, request.ID)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]string{
		"message": "Worker delete successful",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}
func receiveFileHandler(w http.ResponseWriter, r *http.Request) {

	var req FileRequest

	json.NewDecoder(r.Body).Decode(&req)

	fmt.Println("File received:", req.File)

	json.NewEncoder(w).Encode(map[string]string{
		"status": "file received",
	})
}
func TurnOffHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Shutting down system..."))
	// أمر إيقاف التشغيل لنظام Windows (لـ Linux استبدل بـ "shutdown", "-h", "now")
	cmd := exec.Command("shutdown", "/s", "/t", "1")
	cmd.Run()
}

// 2. Task: Receive File from another device
func UploadFileHandler(w http.ResponseWriter, r *http.Request) {
	file, header, err := r.FormFile("file")
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	defer file.Close()

	out, err := os.Create(filepath.Join(".", header.Filename))
	if err != nil {
		http.Error(w, "Unable to create file", http.StatusInternalServerError)
		return
	}
	defer out.Close()

	_, err = io.Copy(out, file)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Write([]byte("File uploaded successfully to Worker 1"))
}

// 3. Task: Change Wallpaper (Windows Example)
func ChangeWallpaperHandler(w http.ResponseWriter, r *http.Request) {
	imagePath := r.URL.Query().Get("path") // نمرر مسار الصورة في الـ URL
	if imagePath == "" {
		http.Error(w, "Missing path parameter", http.StatusBadRequest)
		return
	}

	// استخدام PowerShell لتغيير الخلفية في ويندوز
	asCode := `& {Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop\' -Name wallpaper -Value '` + imagePath + `'; rundll32.exe user32.dll, UpdatePerUserSystemParameters}`
	cmd := exec.Command("powershell", "-Command", asCode)
	err := cmd.Run()
	if err != nil {
		http.Error(w, "Failed to change wallpaper", http.StatusInternalServerError)
		return
	}
	w.Write([]byte("Wallpaper changed successfully"))
}
func UploadFileHandlerS(w http.ResponseWriter, r *http.Request) {

	err := r.ParseMultipartForm(10 << 20)

	if err != nil {

		http.Error(w, err.Error(), http.StatusBadRequest)

		return
	}

	file, handler, err := r.FormFile("file")

	if err != nil {

		http.Error(w, err.Error(), http.StatusBadRequest)

		return
	}

	defer file.Close()

	// folder name

	saveFolder := "./worker1_files"

	os.MkdirAll(saveFolder, os.ModePerm)

	// full path

	savePath := filepath.Join(
		saveFolder,
		handler.Filename,
	)

	dst, err := os.Create(savePath)

	if err != nil {

		http.Error(
			w,
			err.Error(),
			http.StatusInternalServerError,
		)

		return
	}

	defer dst.Close()

	_, err = io.Copy(dst, file)

	if err != nil {

		http.Error(
			w,
			err.Error(),
			http.StatusInternalServerError,
		)

		return
	}

	response := map[string]string{
		"message": "File transferred successfully to Worker 1",
		"path":    savePath,
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}

func selectHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	type SelectRequest struct {
		TableName string `json:"table_name"`
	}

	var request SelectRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf(
		"SELECT * FROM %s",
		request.TableName,
	)

	rows, err := DB.Query(query)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	defer rows.Close()

	columns, _ := rows.Columns()

	var results []map[string]interface{}

	for rows.Next() {

		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))

		for i := range columns {
			valuePtrs[i] = &values[i]
		}

		rows.Scan(valuePtrs...)

		rowData := make(map[string]interface{})

		for i, col := range columns {

			val := values[i]

			b, ok := val.([]byte)

			if ok {
				rowData[col] = string(b)
			} else {
				rowData[col] = val
			}
		}

		results = append(results, rowData)
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(results)
}
