package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
)

type ReplicationRequest struct {
	TableName string                 `json:"table_name"`
	Data      map[string]interface{} `json:"data"`
}
type UpdateRequest struct {
	TableName string `json:"table_name"`
	ID        int    `json:"id"`
	Name      string `json:"name"`
	Age       int    `json:"age"`
}
type DeleteRequest struct {
	TableName string `json:"table_name"`
	ID        int    `json:"id"`
}

func replicationHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request ReplicationRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	createQuery := fmt.Sprintf(
		"CREATE TABLE IF NOT EXISTS %s (id INTEGER PRIMARY KEY AUTOINCREMENT)",
		request.TableName,
	)

	_, err = DB.Exec(createQuery)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	var columns []string
	var placeholders []string
	var values []interface{}

	for key, value := range request.Data {

		columns = append(columns, key)
		placeholders = append(placeholders, "?")
		values = append(values, value)

		alterQuery := fmt.Sprintf(
			"ALTER TABLE %s ADD COLUMN %s TEXT",
			request.TableName,
			key,
		)

		DB.Exec(alterQuery)
	}

	insertQuery := fmt.Sprintf(
		"INSERT INTO %s (%s) VALUES (%s)",
		request.TableName,
		strings.Join(columns, ", "),
		strings.Join(placeholders, ", "),
	)

	_, err = DB.Exec(insertQuery, values...)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]string{
		"message": "Dynamic replication successful",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}

func replicateUpdateHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request UpdateRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf(`
		UPDATE %s
		SET name = ?, age = ?
		WHERE id = ?
	`, request.TableName)

	_, err = DB.Exec(query, request.Name, request.Age, request.ID)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]string{
		"message": "Worker update successful",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}

func replicateDeleteHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request DeleteRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf(
		"DELETE FROM %s WHERE id = ?",
		request.TableName,
	)

	_, err = DB.Exec(query, request.ID)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]string{
		"message": "Worker delete successful",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}
