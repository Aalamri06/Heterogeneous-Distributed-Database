package main

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type Message struct {
	Status string `json:"status"`
}

func homeHandler(w http.ResponseWriter, r *http.Request) {

	response := Message{
		Status: "Worker Node Running",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}

func main() {

	ConnectDatabase()

	http.HandleFunc("/", homeHandler)

	http.HandleFunc("/replicate", replicationHandler)
	http.HandleFunc("/replicate-update", replicateUpdateHandler)
	http.HandleFunc("/replicate-delete", replicateDeleteHandler)

	fmt.Println("Worker Node running on port 8081")

	http.ListenAndServe(":8081", nil)
}
