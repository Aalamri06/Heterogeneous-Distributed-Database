package main

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type Message struct {
	Status string `json:"status"`
}

func enableCORS(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusOK)
			return
		}
		next(w, r)
	}
}

func homeHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "online"})
}

func main() {

	ConnectDatabase()

	http.HandleFunc("/", enableCORS(homeHandler))
	http.HandleFunc("/replicate", replicationHandler)
	http.HandleFunc("/replicate-update", replicateUpdateHandler)
	http.HandleFunc("/replicate-delete", replicateDeleteHandler)
	http.HandleFunc("/receive-file", receiveFileHandler)
	http.HandleFunc("/task/shutdown", TurnOffHandler)
	http.HandleFunc("/task/upload", UploadFileHandlerS)
	http.HandleFunc("/task/wallpaper", ChangeWallpaperHandler)
	http.HandleFunc("/select", selectHandler)

	fmt.Println("Worker Node running on port 8081")

	http.ListenAndServe(":8081", nil)
}
