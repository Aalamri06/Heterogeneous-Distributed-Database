package main

import (
	"database/sql"
	"fmt"

	_ "github.com/mattn/go-sqlite3"
)

var DB *sql.DB

func ConnectDatabase() {

	var err error

	DB, err = sql.Open("sqlite3", "./worker1.db")

	if err != nil {
		panic(err)
	}

	fmt.Println("Worker database connected")
}
