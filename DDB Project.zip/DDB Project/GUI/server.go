package main

import (
	"fmt"
	"html/template"
	"net/http"
)

func dashboardHandler(w http.ResponseWriter, r *http.Request) {

	tmpl := template.Must(
		template.ParseFiles("templates/index.html"),
	)

	tmpl.Execute(w, nil)
}

func main() {

	http.HandleFunc("/", dashboardHandler)

	fmt.Println("GUI running on port 3000")

	http.ListenAndServe(":3000", nil)
}
