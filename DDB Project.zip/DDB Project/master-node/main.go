package main

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type Message struct {
	Status string `json:"status"`
}

func homeHandler(w http.ResponseWriter, r *http.Request) {

	response := Message{
		Status: "Worker Node Running",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}
func enableCors(next http.Handler) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

		if r.Method == "OPTIONS" {
			return
		}

		next.ServeHTTP(w, r)
	})
}

func main() {

	ConnectDatabase()

	go MonitorWorkers()

	http.HandleFunc("/", homeHandler)

	http.HandleFunc("/create-table", createTableHandler)
	http.HandleFunc("/insert", insertHandler)
	http.HandleFunc("/select", selectHandler)
	http.HandleFunc("/update", updateHandler)
	http.HandleFunc("/delete", deleteHandler)
	http.HandleFunc("/columns", columnsHandler)
	http.HandleFunc("/mapreduce", MapReduceQueryHandler)
	http.HandleFunc("/cache-insert", CacheInsertHandler)

	fmt.Println("Master server started on port 8080")

	http.ListenAndServe(":8080", enableCors(http.DefaultServeMux))
}
