package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
)

type Column struct {
	Name string `json:"name"`
	Type string `json:"type"`
}

type CreateTableRequest struct {
	TableName string   `json:"table_name"`
	Columns   []Column `json:"columns"`
}

type InsertRequest struct {
	TableName string                 `json:"table_name"`
	Data      map[string]interface{} `json:"data"`
}
type SelectRequest struct {
	TableName string `json:"table_name"`
}
type UpdateRequest struct {
	TableName string                 `json:"table_name"`
	ID        int                    `json:"id"`
	Data      map[string]interface{} `json:"data"`
}
type DeleteRequest struct {
	TableName string `json:"table_name"`
	ID        int    `json:"id"`
}
type FileRequest struct {
	From string `json:"from"`
	To   string `json:"to"`
	File string `json:"file"`
}

func columnsHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	type Request struct {
		TableName string `json:"table_name"`
	}

	var request Request

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf(
		"PRAGMA table_info(%s)",
		request.TableName,
	)

	rows, err := DB.Query(query)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	defer rows.Close()

	type ColumnInfo struct {
		Name string `json:"name"`
		Type string `json:"type"`
	}

	var columns []ColumnInfo

	for rows.Next() {

		var cid int
		var name string
		var colType string
		var notnull int
		var dflt interface{}
		var pk int

		rows.Scan(
			&cid,
			&name,
			&colType,
			&notnull,
			&dflt,
			&pk,
		)

		if name != "id" {

			columns = append(columns, ColumnInfo{
				Name: name,
				Type: colType,
			})
		}
	}

	w.Header().Set(
		"Content-Type",
		"application/json",
	)

	json.NewEncoder(w).Encode(columns)
}

func createTableHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request CreateTableRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf(
		"CREATE TABLE IF NOT EXISTS %s (id INTEGER PRIMARY KEY AUTOINCREMENT",
		request.TableName,
	)

	for _, column := range request.Columns {

		query += fmt.Sprintf(
			", %s %s",
			column.Name,
			column.Type,
		)
	}

	query += ")"

	_, err = DB.Exec(query)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]string{
		"message": "Dynamic table created successfully",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}

func insertHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request InsertRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	var columns []string
	var placeholders []string
	var values []interface{}

	for key, value := range request.Data {

		columns = append(columns, key)
		placeholders = append(placeholders, "?")
		values = append(values, value)
	}

	query := fmt.Sprintf(
		"INSERT INTO %s (%s) VALUES (%s)",
		request.TableName,
		strings.Join(columns, ", "),
		strings.Join(placeholders, ", "),
	)

	_, err = DB.Exec(query, values...)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	go ReplicateData(request)

	response := map[string]string{
		"message": "Dynamic insert successful",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}
func selectHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request SelectRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Dynamic query

	query := fmt.Sprintf(
		"SELECT * FROM %s",
		request.TableName,
	)

	rows, err := DB.Query(query)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	defer rows.Close()

	// Get all columns dynamically

	columns, err := rows.Columns()

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	var results []map[string]interface{}

	for rows.Next() {

		// Dynamic scan

		values := make([]interface{}, len(columns))

		valuePtrs := make([]interface{}, len(columns))

		for i := range columns {
			valuePtrs[i] = &values[i]
		}

		err := rows.Scan(valuePtrs...)

		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		rowData := make(map[string]interface{})

		for i, col := range columns {

			val := values[i]

			// SQLite returns []byte sometimes

			b, ok := val.([]byte)

			if ok {
				rowData[col] = string(b)
			} else {
				rowData[col] = val
			}
		}

		results = append(results, rowData)
	}

	w.Header().Set(
		"Content-Type",
		"application/json",
	)

	json.NewEncoder(w).Encode(results)
}

func updateHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request UpdateRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// تجهيز الـ SET ديناميك
	var setParts []string
	var values []interface{}

	for column, value := range request.Data {

		setParts = append(setParts,
			fmt.Sprintf("%s = ?", column),
		)

		values = append(values, value)
	}

	// إضافة الـ ID في النهاية
	values = append(values, request.ID)

	query := fmt.Sprintf(`
		UPDATE %s
		SET %s
		WHERE id = ?
	`,
		request.TableName,
		strings.Join(setParts, ", "),
	)

	_, err = DB.Exec(query, values...)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	go ReplicateDynamicUpdate(request)

	response := map[string]string{
		"message": "Dynamic update successful",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}
func ReplicateDynamicUpdate(request UpdateRequest) {

	workers := []string{
		"http://localhost:8081/update",
		"http://localhost:8082/update",
	}

	jsonData, _ := json.Marshal(request)

	for _, worker := range workers {

		http.Post(
			worker,
			"application/json",
			bytes.NewBuffer(jsonData),
		)
	}
}
func deleteHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request DeleteRequest
	go ReplicateDelete(request)

	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf("DELETE FROM %s WHERE id = ?", request.TableName)

	_, err = DB.Exec(query, request.ID)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]string{
		"message": "Record deleted successfully",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func MapReduceQueryHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// استقبال الـ Query القادمة من الـ GUI
	var queryBody map[string]interface{}
	json.NewDecoder(r.Body).Decode(&queryBody)

	// عناوين الـ Workers الذين يمتلكون الداتا
	workers := []string{
		"http://localhost:8081/select", // Worker 1 (Go)
		"http://localhost:8082/select", // Worker 2 (Python)
	}

	var combinedResults []interface{}

	// مرحلة الـ Map: إرسال الـ Query لكل العقد بالتوازي أو التوالي
	for _, workerURl := range workers {
		jsonValue, _ := json.Marshal(queryBody)
		resp, err := http.Post(workerURl, "application/json", bytes.NewBuffer(jsonValue))
		if err != nil {
			continue // تخطي السيرفر الواقع (Fault Tolerance)
		}
		defer resp.Body.Close()

		body, _ := io.ReadAll(resp.Body)
		var workerData []interface{}
		json.Unmarshal(body, &workerData)

		// مرحلة الـ Reduce: تجميع البيانات في مصفوفة واحدة
		combinedResults = append(combinedResults, workerData...)
	}

	// إرسال النتيجة النهائية المجمعة للـ GUI
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(combinedResults)
}

// كاش مؤقت في الذاكرة يحاكي الـ Cache Device
var cacheStorage []map[string]interface{}
var cacheMutex sync.Mutex

type CacheRequest struct {
	TableName string                 `json:"table_name"`
	Data      map[string]interface{} `json:"data"`
}

func CacheInsertHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var request CacheRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	cacheMutex.Lock()

	cacheStorage = append(cacheStorage, request.Data)

	cacheMutex.Unlock()

	err = InsertIntoMainDatabase(
		request.TableName,
		request.Data,
	)

	if err != nil {

		http.Error(
			w,
			err.Error(),
			http.StatusInternalServerError,
		)

		return
	}

	cacheMutex.Lock()

	cacheStorage = []map[string]interface{}{}

	cacheMutex.Unlock()

	w.Write([]byte(
		"Data stored in Cache -> forwarded to Main -> cache cleared successfully",
	))
}
func InsertIntoMainDatabase(
	tableName string,
	data map[string]interface{},
) error {

	var columns []string
	var placeholders []string
	var values []interface{}

	for key, value := range data {

		columns = append(columns, key)

		placeholders = append(placeholders, "?")

		values = append(values, value)
	}

	query := fmt.Sprintf(
		"INSERT INTO %s (%s) VALUES (%s)",
		tableName,
		strings.Join(columns, ", "),
		strings.Join(placeholders, ", "),
	)

	_, err := DB.Exec(query, values...)

	return err
}
