package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
)

type Column struct {
	Name string `json:"name"`
	Type string `json:"type"`
}

type CreateTableRequest struct {
	TableName string   `json:"table_name"`
	Columns   []Column `json:"columns"`
}

type InsertRequest struct {
	TableName string                 `json:"table_name"`
	Data      map[string]interface{} `json:"data"`
}
type SelectRequest struct {
	TableName string `json:"table_name"`
}
type UpdateRequest struct {
	TableName string `json:"table_name"`
	ID        int    `json:"id"`
	Name      string `json:"name"`
	Age       int    `json:"age"`
}
type DeleteRequest struct {
	TableName string `json:"table_name"`
	ID        int    `json:"id"`
}

func columnsHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	type Request struct {
		TableName string `json:"table_name"`
	}

	var request Request

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf(
		"PRAGMA table_info(%s)",
		request.TableName,
	)

	rows, err := DB.Query(query)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	defer rows.Close()

	type ColumnInfo struct {
		Name string `json:"name"`
		Type string `json:"type"`
	}

	var columns []ColumnInfo

	for rows.Next() {

		var cid int
		var name string
		var colType string
		var notnull int
		var dflt interface{}
		var pk int

		rows.Scan(
			&cid,
			&name,
			&colType,
			&notnull,
			&dflt,
			&pk,
		)

		if name != "id" {

			columns = append(columns, ColumnInfo{
				Name: name,
				Type: colType,
			})
		}
	}

	w.Header().Set(
		"Content-Type",
		"application/json",
	)

	json.NewEncoder(w).Encode(columns)
}

func createTableHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request CreateTableRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf(
		"CREATE TABLE IF NOT EXISTS %s (id INTEGER PRIMARY KEY AUTOINCREMENT",
		request.TableName,
	)

	for _, column := range request.Columns {

		query += fmt.Sprintf(
			", %s %s",
			column.Name,
			column.Type,
		)
	}

	query += ")"

	_, err = DB.Exec(query)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]string{
		"message": "Dynamic table created successfully",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}

func insertHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request InsertRequest

	err := json.NewDecoder(r.Body).Decode(&request)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	var columns []string
	var placeholders []string
	var values []interface{}

	for key, value := range request.Data {

		columns = append(columns, key)
		placeholders = append(placeholders, "?")
		values = append(values, value)
	}

	query := fmt.Sprintf(
		"INSERT INTO %s (%s) VALUES (%s)",
		request.TableName,
		strings.Join(columns, ", "),
		strings.Join(placeholders, ", "),
	)

	_, err = DB.Exec(query, values...)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	go ReplicateData(request)

	response := map[string]string{
		"message": "Dynamic insert successful",
	}

	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}
func selectHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request SelectRequest

	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf("SELECT id, name, age FROM %s", request.TableName)

	rows, err := DB.Query(query)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	type Row struct {
		ID   int    `json:"id"`
		Name string `json:"name"`
		Age  int    `json:"age"`
	}

	var results []Row

	for rows.Next() {
		var r Row
		rows.Scan(&r.ID, &r.Name, &r.Age)
		results = append(results, r)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(results)
}

func updateHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request UpdateRequest
	go ReplicateUpdate(request)

	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf(`
		UPDATE %s
		SET name = ?, age = ?
		WHERE id = ?
	`, request.TableName)

	_, err = DB.Exec(query, request.Name, request.Age, request.ID)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]string{
		"message": "Record updated successfully",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func deleteHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusBadRequest)
		return
	}

	var request DeleteRequest
	go ReplicateDelete(request)

	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := fmt.Sprintf("DELETE FROM %s WHERE id = ?", request.TableName)

	_, err = DB.Exec(query, request.ID)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]string{
		"message": "Record deleted successfully",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}
