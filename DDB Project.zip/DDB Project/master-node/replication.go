package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
)

func ReplicateData(data InsertRequest) {

	jsonData, err := json.Marshal(data)
	if err != nil {
		fmt.Println("Replication marshal error:", err)
		return
	}

	url := "http://localhost:8081/replicate"

	response, err := http.Post(
		url,
		"application/json",
		bytes.NewBuffer(jsonData),
	)

	if err != nil {
		fmt.Println("Replication failed:", err)
		return
	}

	defer response.Body.Close()

	fmt.Println("Replication sent successfully")
}

func ReplicateUpdate(data UpdateRequest) {

	jsonData, err := json.Marshal(data)

	if err != nil {
		fmt.Println(err)
		return
	}

	workerURLs := []string{
		"http://localhost:8081/replicate-update",
		"http://localhost:8082/replicate-update",
	}

	for _, url := range workerURLs {

		_, err := http.Post(
			url,
			"application/json",
			bytes.NewBuffer(jsonData),
		)

		if err != nil {
			fmt.Println("Update replication failed:", err)
			continue
		}

		fmt.Println("Update replicated to:", url)
	}
}
func ReplicateDelete(data DeleteRequest) {

	jsonData, err := json.Marshal(data)

	if err != nil {
		fmt.Println(err)
		return
	}

	workerURLs := []string{
		"http://localhost:8081/replicate-delete",
		"http://localhost:8082/replicate-delete",
	}

	for _, url := range workerURLs {

		_, err := http.Post(
			url,
			"application/json",
			bytes.NewBuffer(jsonData),
		)

		if err != nil {
			fmt.Println("Delete replication failed:", err)
			continue
		}

		fmt.Println("Delete replicated to:", url)
	}
}
