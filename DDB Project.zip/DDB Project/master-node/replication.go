package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"hash/fnv"
	"net/http"
)

// دالة لحساب الـ Hash وقيمته وعرض السيرفر المقترح نظرياً (دون حجب السيرفر الآخر)
func logHashDistribution(key string) {
	h := fnv.New32a()
	h.Write([]byte(key))
	hashValue := h.Sum32()
	nodeIndex := hashValue % 2

	fmt.Printf("[Hashing System] Data Key: '%s' | Hash Value: %d | Assigned to Worker: %d\n", key, hashValue, nodeIndex+1)
}

// 1. Replicate Data (Insert) - يرسل للـ 2 Workers مع حساب الـ Hash
func ReplicateData(data InsertRequest) {
	jsonData, err := json.Marshal(data)
	if err != nil {
		fmt.Println("Replication marshal error:", err)
		return
	}

	// حساب الـ Hash وعرضه في السيرفر لتوثيق المهمة الثالثة
	routingKey := fmt.Sprintf("%v", data)
	logHashDistribution(routingKey)

	// إرسال البيانات للـ 2 Workers لضمان وصولها للجميع دون تأثر المشروع
	workerURLs := []string{
		"http://localhost:8081/replicate",
		"http://localhost:8082/replicate", // تأكد أن السيرفر الثاني لديه هذا الـ endpoint أيضاً
	}

	for _, url := range workerURLs {
		response, err := http.Post(url, "application/json", bytes.NewBuffer(jsonData))
		if err != nil {
			fmt.Printf("Replication failed for URL %s: %v\n", url, err)
			continue
		}
		defer response.Body.Close()
		fmt.Println("Insert Replicated to:", url)
	}
}

// 2. Replicate Update - يرسل للـ 2 Workers مع حساب الـ Hash
func ReplicateUpdate(data UpdateRequest) {
	jsonData, err := json.Marshal(data)
	if err != nil {
		fmt.Println(err)
		return
	}

	routingKey := fmt.Sprintf("%v", data)
	logHashDistribution(routingKey)

	workerURLs := []string{
		"http://localhost:8081/replicate-update",
		"http://localhost:8082/replicate-update",
	}

	for _, url := range workerURLs {
		_, err := http.Post(url, "application/json", bytes.NewBuffer(jsonData))
		if err != nil {
			fmt.Println("Update replication failed:", err)
			continue
		}
		fmt.Println("Update replicated to:", url)
	}
}

// 3. Replicate Delete - يرسل للـ 2 Workers مع حساب الـ Hash
func ReplicateDelete(data DeleteRequest) {
	jsonData, err := json.Marshal(data)
	if err != nil {
		fmt.Println(err)
		return
	}

	routingKey := fmt.Sprintf("%v", data)
	logHashDistribution(routingKey)

	workerURLs := []string{
		"http://localhost:8081/replicate-delete",
		"http://localhost:8082/replicate-delete",
	}

	for _, url := range workerURLs {
		_, err := http.Post(url, "application/json", bytes.NewBuffer(jsonData))
		if err != nil {
			fmt.Println("Delete replication failed:", err)
			continue
		}
		fmt.Println("Delete replicated to:", url)
	}
}
