package main

import (
	"fmt"
	"net/http"
	"time"
)

func IsWorkerAlive(url string) bool {

	client := http.Client{
		Timeout: 2 * time.Second,
	}

	response, err := client.Get(url)

	if err != nil {
		return false
	}

	defer response.Body.Close()

	return response.StatusCode == 200
}

func MonitorWorkers() {

	for {

		worker1 := IsWorkerAlive("http://localhost:8081")
		worker2 := IsWorkerAlive("http://localhost:8082")

		if worker1 {
			fmt.Println("Worker 1 (Go) is ONLINE")
		} else {
			fmt.Println("Worker 1 (Go) is OFFLINE")
		}

		if worker2 {
			fmt.Println("Worker 2 (Python) is ONLINE")
		} else {
			fmt.Println("Worker 2 (Python) is OFFLINE")
		}

		fmt.Println("----------------------------")

		time.Sleep(5 * time.Second)
	}
}
