from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

DATABASE = "worker2.db"


def connect_db():
    return sqlite3.connect(DATABASE)


@app.route("/")
def home():
    return jsonify({
        "status": "Python Worker Running"
    })


@app.route("/replicate", methods=["POST"])
def replicate():

    data = request.json

    table_name = data["table_name"]
    dynamic_data = data["data"]

    conn = connect_db()

    cursor = conn.cursor()

    create_query = f'''
    CREATE TABLE IF NOT EXISTS {table_name} (
        id INTEGER PRIMARY KEY AUTOINCREMENT
    )
    '''

    cursor.execute(create_query)

    for key in dynamic_data.keys():

        try:
            alter_query = f'''
            ALTER TABLE {table_name}
            ADD COLUMN {key} TEXT
            '''

            cursor.execute(alter_query)

        except:
            pass

    columns = ", ".join(dynamic_data.keys())

    placeholders = ", ".join(["?"] * len(dynamic_data))

    values = list(dynamic_data.values())

    insert_query = f'''
    INSERT INTO {table_name}
    ({columns})
    VALUES ({placeholders})
    '''

    cursor.execute(insert_query, values)

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Dynamic replication successful"
    })
@app.route("/replicate-update", methods=["POST"])
def replicate_update():

    data = request.json

    table_name = data["table_name"]
    record_id = data["id"]
    name = data["name"]
    age = data["age"]

    conn = connect_db()

    cursor = conn.cursor()

    query = f"""
    UPDATE {table_name}
    SET name=?, age=?
    WHERE id=?
    """

    cursor.execute(query, (name, age, record_id))

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Update replicated in Python worker"
    })


@app.route("/replicate-delete", methods=["POST"])
def replicate_delete():

    data = request.json

    table_name = data["table_name"]
    record_id = data["id"]

    conn = connect_db()

    cursor = conn.cursor()

    query = f"DELETE FROM {table_name} WHERE id=?"

    cursor.execute(query, (record_id,))

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Delete replicated in Python worker"
    })
@app.route("/select", methods=["POST"])
def select_data():

    data = request.json

    table_name = data["table_name"]

    conn = connect_db()

    conn.row_factory = sqlite3.Row

    cursor = conn.cursor()

    query = f"SELECT * FROM {table_name}"

    rows = cursor.execute(query).fetchall()

    conn.close()

    results = []

    for row in rows:
        results.append(dict(row))

    return jsonify(results)
@app.route("/insert", methods=["POST"])
def insert_data():

    data = request.json

    table_name = data["table_name"]
    name = data["name"]
    age = data["age"]

    conn = connect_db()

    cursor = conn.cursor()

    create_query = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        age INTEGER
    )
    """

    cursor.execute(create_query)

    query = f"""
    INSERT INTO {table_name}(name, age)
    VALUES (?, ?)
    """

    cursor.execute(query, (name, age))

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Inserted successfully in Python worker"
    })

@app.route("/update", methods=["POST"])
def update_data():

    data = request.json

    table_name = data["table_name"]
    record_id = data["id"]
    name = data["name"]
    age = data["age"]

    conn = connect_db()

    cursor = conn.cursor()

    query = f"""
    UPDATE {table_name}
    SET name=?, age=?
    WHERE id=?
    """

    cursor.execute(query, (name, age, record_id))

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Updated successfully in Python worker"
    })

@app.route("/delete", methods=["POST"])
def delete_data():

    data = request.json

    table_name = data["table_name"]
    record_id = data["id"]

    conn = connect_db()

    cursor = conn.cursor()

    query = f"DELETE FROM {table_name} WHERE id=?"

    cursor.execute(query, (record_id,))

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Deleted successfully in Python worker"
    })


if __name__ == "__main__":
    app.run(port=8082, debug=True)