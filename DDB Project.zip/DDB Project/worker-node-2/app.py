import os
import ctypes
import sqlite3

from flask import Flask, request, jsonify
from flask_cors import CORS

# =========================================================
# APP CONFIG
# =========================================================

app = Flask(__name__)

CORS(app)

DATABASE = "worker2.db"

# =========================================================
# DATABASE CONNECTION
# =========================================================

def connect_db():

    return sqlite3.connect(DATABASE)

# =========================================================
# HOME
# =========================================================

@app.route("/", methods=["GET"])
def home():

    return jsonify({
        "status": "online",
        "message": "Python Worker Running"
    }), 200

# =========================================================
# REPLICATION INSERT
# =========================================================

@app.route("/replicate", methods=["POST"])
def replicate():

    data = request.json

    table_name = data["table_name"]

    dynamic_data = data["data"]

    conn = connect_db()

    cursor = conn.cursor()

    create_query = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
        id INTEGER PRIMARY KEY AUTOINCREMENT
    )
    """

    cursor.execute(create_query)

    # CREATE MISSING COLUMNS

    for key in dynamic_data.keys():

        try:

            alter_query = f"""
            ALTER TABLE {table_name}
            ADD COLUMN {key} TEXT
            """

            cursor.execute(alter_query)

        except:
            pass

    columns = ", ".join(dynamic_data.keys())

    placeholders = ", ".join(
        ["?"] * len(dynamic_data)
    )

    values = list(dynamic_data.values())

    insert_query = f"""
    INSERT INTO {table_name}
    ({columns})
    VALUES ({placeholders})
    """

    cursor.execute(insert_query, values)

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Dynamic replication successful"
    })

# =========================================================
# REPLICATION UPDATE
# =========================================================

@app.route("/replicate-update", methods=["POST"])
def replicate_update():

    data = request.json

    table_name = data["table_name"]

    record_id = data["id"]

    dynamic_data = data["data"]

    conn = connect_db()

    cursor = conn.cursor()

    set_parts = []

    values = []

    for key, value in dynamic_data.items():

        set_parts.append(f"{key}=?")

        values.append(value)

    values.append(record_id)

    query = f"""
    UPDATE {table_name}
    SET {", ".join(set_parts)}
    WHERE id=?
    """

    cursor.execute(query, values)

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Dynamic update replicated"
    })

# =========================================================
# REPLICATION DELETE
# =========================================================

@app.route("/replicate-delete", methods=["POST"])
def replicate_delete():

    data = request.json

    table_name = data["table_name"]

    record_id = data["id"]

    conn = connect_db()

    cursor = conn.cursor()

    query = f"""
    DELETE FROM {table_name}
    WHERE id=?
    """

    cursor.execute(query, (record_id,))

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Delete replicated"
    })

# =========================================================
# SELECT
# =========================================================

@app.route("/select", methods=["POST"])
def select_data():

    data = request.json

    table_name = data["table_name"]

    conn = connect_db()

    conn.row_factory = sqlite3.Row

    cursor = conn.cursor()

    query = f"SELECT * FROM {table_name}"

    rows = cursor.execute(query).fetchall()

    conn.close()

    results = []

    for row in rows:

        results.append(dict(row))

    return jsonify(results)

# =========================================================
# INSERT
# =========================================================

@app.route("/insert", methods=["POST"])
def insert_data():

    data = request.json

    table_name = data["table_name"]

    dynamic_data = data["data"]

    conn = connect_db()

    cursor = conn.cursor()

    # CREATE TABLE

    create_query = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
        id INTEGER PRIMARY KEY AUTOINCREMENT
    )
    """

    cursor.execute(create_query)

    # CREATE COLUMNS

    for key in dynamic_data.keys():

        try:

            alter_query = f"""
            ALTER TABLE {table_name}
            ADD COLUMN {key} TEXT
            """

            cursor.execute(alter_query)

        except:
            pass

    columns = ", ".join(dynamic_data.keys())

    placeholders = ", ".join(
        ["?"] * len(dynamic_data)
    )

    values = list(dynamic_data.values())

    query = f"""
    INSERT INTO {table_name}
    ({columns})
    VALUES ({placeholders})
    """

    cursor.execute(query, values)

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Inserted successfully"
    })

# =========================================================
# UPDATE
# =========================================================

@app.route("/update", methods=["POST"])
def update_data():

    data = request.json

    table_name = data["table_name"]

    record_id = data["id"]

    dynamic_data = data["data"]

    conn = connect_db()

    cursor = conn.cursor()

    set_parts = []

    values = []

    for key, value in dynamic_data.items():

        set_parts.append(f"{key}=?")

        values.append(value)

    values.append(record_id)

    query = f"""
    UPDATE {table_name}
    SET {", ".join(set_parts)}
    WHERE id=?
    """

    cursor.execute(query, values)

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Dynamic update successful"
    })

# =========================================================
# DELETE
# =========================================================

@app.route("/delete", methods=["POST"])
def delete_data():

    data = request.json

    table_name = data["table_name"]

    record_id = data["id"]

    conn = connect_db()

    cursor = conn.cursor()

    query = f"""
    DELETE FROM {table_name}
    WHERE id=?
    """

    cursor.execute(query, (record_id,))

    conn.commit()

    conn.close()

    return jsonify({
        "message": "Deleted successfully"
    })

# =========================================================
# TASK 1 — SHUTDOWN DEVICE
# =========================================================

@app.route('/task/shutdown', methods=['POST'])
def shutdown_device():

    os.system("shutdown /s /t 1")

    return jsonify({
        "message": "Shutting down Worker 2..."
    }), 200

# =========================================================
# TASK 1 — FILE TRANSFER
# =========================================================

@app.route('/task/upload', methods=['POST'])
def upload_file():

    if 'file' not in request.files:

        return jsonify({
            "error": "No file uploaded"
        }), 400

    file = request.files['file']

    if file.filename == '':

        return jsonify({
            "error": "Empty filename"
        }), 400

    save_folder = "./worker2_files"

    os.makedirs(save_folder, exist_ok=True)

    save_path = os.path.join(
        save_folder,
        file.filename
    )

    file.save(save_path)

    return jsonify({
        "message": "File transferred successfully to Worker 2",
        "path": save_path
    }), 200

# =========================================================
# TASK 1 — CHANGE WALLPAPER
# =========================================================

@app.route('/task/wallpaper', methods=['POST'])
def change_wallpaper():

    data = request.get_json()

    image_path = data.get('path')

    if not image_path:

        return jsonify({
            "error": "Missing path"
        }), 400

    ctypes.windll.user32.SystemParametersInfoW(
        20,
        0,
        image_path,
        3
    )

    return jsonify({
        "message": "Wallpaper changed successfully"
    }), 200

# =========================================================
# MAIN
# =========================================================

if __name__ == "__main__":

    print("Python Worker running on port 8082")

    app.run(
        host="0.0.0.0",
        port=8082,
        debug=True
    )